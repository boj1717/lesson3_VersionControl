## Project Name:  Expense Calculator Application

### Course Title:
Web Application Development

### Assignment Date:  
(October 19, 2018)

### Student Name:  
(Benjamen Johnson)

### Project Description:
(Complete the expense calculator file, by providing the missing code.)

### View Project:
(Replace this statement with your GitHub Page URL that was created when you 
 published the project.)

### Lessons Learned in the Assignment:
1. (Briefly describe a lesson/concept learned in this lesson.)
2. (Briefly describe a lesson/concept learned in this lesson.)
3. (Briefly describe a lesson/concept learned in this lesson.)



# lesson4_javascript1_1
# lesson4_javascript1
